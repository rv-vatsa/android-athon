package com.example.rvijaykumarshahi.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Toast;

/**
 * Created by r.vijaykumarshahi on 5/15/2016.
 */
public class CircularProgress extends View {
    private int progress;
    private float angle;
    private int maximum_progress = 24;
    private int textSize = 26;
    private RectF rectF;
    private float startAngle;
    private int min;
    private float PADDING = 20;
    private float bottom;
    private float right;
    private float top;
    private float left;
    private int circleTxtPadding;
    private Paint backgroundPaint,foregroundPaint, textPaint;
    private float backgroundStrokeWidth = 15f;
    private float strokeWidth = 15f;
    private int height, width;
    private Context context;


    public CircularProgress(Context context) {
        super(context);
        init(context);
    }

    public CircularProgress(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);

    }

    protected void init(Context ctx) {
        context = ctx;
        rectF = new RectF();
        setProgress(0);
        backgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        backgroundPaint.setColor(Color.parseColor("#000000"));
        backgroundPaint.setStyle(Paint.Style.STROKE);
        backgroundPaint.setStrokeWidth(3f);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.parseColor("#0097A7"));
        textPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        textPaint.setStrokeWidth(1f);
        textPaint.setTextSize(textSize);

        foregroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        foregroundPaint.setColor(Color.parseColor("#FF4081"));
        foregroundPaint.setStyle(Paint.Style.STROKE);
        foregroundPaint.setStrokeWidth(strokeWidth);

    }

    public void setProgress(int progress) {
        setProgressInView(progress);

    }
    private synchronized void setProgressInView(int progress) {
        this.progress = progress;
        invalidate();

    }

    @Override
    protected synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        startAngle = 270;
        angle = 360 * progress / maximum_progress;
        canvas.drawArc(rectF, startAngle, 360, false, backgroundPaint); // Initially circle painted in background color

        if (progress > 0)
            canvas.drawArc(rectF, startAngle, angle, false, foregroundPaint);
    }


    @Override
    protected synchronized void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        min = setDimensions(widthMeasureSpec, heightMeasureSpec);
        left = 50 +strokeWidth;
        top = 100 + strokeWidth;
        right = min - strokeWidth;
        bottom = min - strokeWidth;
        rectF.set(left + PADDING , top + PADDING , right - PADDING, bottom
                - PADDING);
    }

    protected int setDimensions(int widthMeasureSpec, int heightMeasureSpec) {
        height = getDefaultSize(getSuggestedMinimumHeight(), heightMeasureSpec);
        width = getDefaultSize(getSuggestedMinimumWidth(), widthMeasureSpec);

        final int smallerDimens = Math.min(width, height);

        setMeasuredDimension(smallerDimens, smallerDimens);
        return smallerDimens;
    }
}
